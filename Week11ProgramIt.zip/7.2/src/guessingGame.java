/* Lola Kovalski
*Guessing Game Program (Again)
*The exact same game as in project 7.1, except this time, the computer guesses the number
*~References: https://docs.oracle.com/javase/7/docs/api/
*/

import java.util.Random;  //creates random number generator
import java.util.Scanner; //creates scanner: will be used to interact with user



public class guessingGame {
	
	  public static int MaximumGuess = 100;   // the highest possible number the computer can guess
	  public static int MinimumGuess = 1;     // lowest number the computer can guess
	  public static int ComputerGuess = 1;   // current computer guess
	  public static int UserNumber; 			// the variable for the number guessed by the user
	  public static int Attempts = 0;      // the number of times the computer had to guess the number

	  
	  public static void main (String [] args) {
		  Scanner input = new Scanner(System.in);
		  Random random = new Random ();
		  
		  System.out.println("Think of a number between 1 and 100.This computer will attempt to randomly guess that number. Type it here: (we promise the computer won't cheat)");
		  UserNumber= input.nextInt();
		  
		  
		  while (UserNumber != ComputerGuess) { 
			  
			  
			  ComputerGuess = random.nextInt(MaximumGuess - MinimumGuess + 1) + MinimumGuess; //computer chooses a random number between 1 and 100
			  System.out.println("I think your number is, " + ComputerGuess + ".");

		      
		      if (ComputerGuess < UserNumber) { //if the computer guessed a number less than the user's
		    	  MinimumGuess = ComputerGuess;      //updates the range of numbers the computer can guess based on user response
			      Attempts++;
		     
		      }
		      if (ComputerGuess > UserNumber) {    //if the computer guessed a number greater than the user's
		    	  MaximumGuess = ComputerGuess;       //updates the range of numbers the computer can guess based on user response
			      Attempts++;
		      }


		      else if (ComputerGuess == UserNumber) {
		    	  Result(); 
		      }
		  }

	  }


	public static void Result() {
		 System.out.println("After " + Attempts + " attempts, I finally guessed your number. Thanks for playing!");
		
	}
	  
}
