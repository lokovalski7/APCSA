/* Lola Kovalski
*Guessing Game Program
*Computer randomly selects a number and user attempts to guess it
*~References: https://docs.oracle.com/javase/7/docs/api/
*/


import java.util.Random;  //creates random number generator
import java.util.Scanner; //creates scanner: will be used to interact with user



public class guessingGame {

	static Random random = new Random ();
	
	public static int Number = random.nextInt(100 - 1 + 1) + 1; //randomly picks a number between 1 and 100
	public static int Guess; //variable for the user's guesses
	public static int Attempts; //keeps track of how many times user guesses number
	
	public static void main (String args[]) {
		Scanner input = new Scanner(System.in);
		System.out.println("Guess a number between 1 and 100.");
		
		
		while(Number != Guess) {   //loop repeats when the user has not guessed the number properly yet
			 
			Guess = input.nextInt();
			
			
			if (Guess > Number) {											//if the guess is more than the number
				System.out.println("Your guess is too high. Try again.");
				Attempts ++; 
			}
			if (Guess < Number) {											//if the guess is less than the number
				System.out.println("Your guess is too low.Try again.");
				Attempts ++;
			}
			
			
			
		}
		
		
		if (Guess == Number) { 												//if the user is correct
			Results(); 
			Attempts ++ ;
		}
		
	}

	private static void Results() {
		System.out.println("Great Work. You guessed the number correctly. It only took you " + Attempts + " attempts!");
		
	}
	
	
}



//Comments about the week
/*
* For starters, I really enjoyed the random class. I found it really interesting and relatively easy to use. I also was fascinated by its
* potential applications in the world of cyber security. This weeks program it activity was fun as well, because conditionals are absolutely 
* amazing! It is so fun to integrate user inputed data and conditional statements.
*/